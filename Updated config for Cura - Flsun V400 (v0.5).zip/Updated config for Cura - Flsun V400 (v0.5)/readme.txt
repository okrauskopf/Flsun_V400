1. Place the "flsun_v400 folder" in the "share\cura\resources\quality" directory under the cura5.0 installation path.

2. Place the "flsun_v400.def.json" file to "share\cura\resources\definitions" directory in the installation path.

3. Place the "flsun_v400_extruder_0.def.json" file in the "share\cura\resources\extruders" directory in the installation path.

4. Place the "flsun_v400. stl" file under the "share\cura\resources\meshes" directory in the installation path.

5. Close all open CURA software and add V400 after opening it again.